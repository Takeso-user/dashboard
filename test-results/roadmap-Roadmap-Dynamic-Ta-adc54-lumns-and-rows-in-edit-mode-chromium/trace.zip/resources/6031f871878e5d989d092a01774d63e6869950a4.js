import { RoadmapManager } from "/src/roadmap.ts";
document.addEventListener("DOMContentLoaded", async () => {
  const manager = new RoadmapManager();
  const tableHeader = document.getElementById("roadmap-table-header");
  const tableBody = document.getElementById("roadmap-table-body");
  const btnToggleEdit = document.getElementById("btn-toggle-edit");
  const editToggleLabel = document.getElementById("edit-toggle-label");
  const btnAddCol = document.getElementById("btn-add-col");
  const btnAddRow = document.getElementById("btn-add-row");
  const btnAddRowBottom = document.getElementById("btn-add-row-bottom");
  const btnSaveDb = document.getElementById("btn-save-db");
  const btnExportJson = document.getElementById("btn-export-json");
  const inputImportJson = document.getElementById("input-import-json");
  const btnResetDemo = document.getElementById("btn-reset-demo");
  const metricOverallPct = document.getElementById("metric-overall-pct");
  const progressBarFill = document.getElementById("progress-bar-fill");
  const metricCompletedCount = document.getElementById("metric-completed-count");
  const metricRowsCount = document.getElementById("metric-rows-count");
  const toastContainer = document.getElementById("toast-container");
  let activePopover = null;
  function showToast(message, type = "success") {
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${type === "success" ? "✅" : "ℹ️"}</span><span>${message}</span>`;
    toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(10px)";
      toast.style.transition = "all 0.3s ease";
      setTimeout(() => toast.remove(), 300);
    }, 2800);
  }
  function closeActivePopover() {
    if (activePopover) {
      activePopover.remove();
      activePopover = null;
    }
  }
  document.addEventListener("click", (e) => {
    if (activePopover && !activePopover.contains(e.target)) {
      closeActivePopover();
    }
  });
  function renderMetrics() {
    const metrics = manager.getMetrics();
    metricOverallPct.textContent = `${metrics.overallPct}%`;
    progressBarFill.style.width = `${metrics.overallPct}%`;
    metricCompletedCount.textContent = `${metrics.completedCells} / ${metrics.totalActiveCells}`;
    metricRowsCount.textContent = `${metrics.totalRows}`;
  }
  function renderTable() {
    const data = manager.getData();
    const isEditMode = manager.getEditMode();
    if (isEditMode) {
      document.body.classList.add("edit-mode");
      btnToggleEdit.classList.add("active");
      editToggleLabel.textContent = "Lock Structure (View Mode)";
    } else {
      document.body.classList.remove("edit-mode");
      btnToggleEdit.classList.remove("active");
      editToggleLabel.textContent = "Edit Table Structure";
    }
    tableHeader.innerHTML = "";
    const thTrack = document.createElement("th");
    thTrack.className = "track-col-header";
    thTrack.innerHTML = `
      <div class="col-header-content">
        <span>Feature / Work Track</span>
      </div>
    `;
    tableHeader.appendChild(thTrack);
    data.columns.forEach((col) => {
      const th = document.createElement("th");
      th.setAttribute("data-col-id", col.id);
      if (isEditMode) {
        th.innerHTML = `
          <div class="col-header-content">
            <span class="col-title-text" contenteditable="true" data-col-id="${col.id}">${escapeHtml(col.title)}</span>
            <div class="col-actions">
              <button class="btn-icon btn-danger delete-col-btn" data-col-id="${col.id}" title="Delete column">🗑️</button>
            </div>
          </div>
        `;
      } else {
        th.innerHTML = `
          <div class="col-header-content">
            <span class="col-title-text">${escapeHtml(col.title)}</span>
          </div>
        `;
      }
      tableHeader.appendChild(th);
    });
    if (isEditMode) {
      const thAdd = document.createElement("th");
      thAdd.style.width = "140px";
      thAdd.innerHTML = `
        <button class="add-col-header-btn" id="btn-add-col-header">
          ➕ Add Column
        </button>
      `;
      tableHeader.appendChild(thAdd);
    }
    tableBody.innerHTML = "";
    data.rows.forEach((row) => {
      const tr = document.createElement("tr");
      tr.setAttribute("data-row-id", row.id);
      const tdTrack = document.createElement("td");
      tdTrack.className = "track-cell";
      if (isEditMode) {
        tdTrack.innerHTML = `
          <div class="track-content">
            <div class="track-info">
              <span class="track-name" contenteditable="true" data-row-id="${row.id}">${escapeHtml(row.title)}</span>
              <span class="track-badge" contenteditable="true" data-row-cat-id="${row.id}">${escapeHtml(row.category || "Feature")}</span>
            </div>
            <div class="track-actions">
              <button class="btn-icon btn-danger delete-row-btn" data-row-id="${row.id}" title="Delete row">🗑️</button>
            </div>
          </div>
        `;
      } else {
        tdTrack.innerHTML = `
          <div class="track-content">
            <div class="track-info">
              <span class="track-name">${escapeHtml(row.title)}</span>
              <span class="track-badge">${escapeHtml(row.category || "Feature")}</span>
            </div>
          </div>
        `;
      }
      tr.appendChild(tdTrack);
      data.columns.forEach((col) => {
        const cell = row.cells[col.id] || { type: "active", checked: false, percentage: 0 };
        const td = document.createElement("td");
        td.className = "roadmap-cell";
        td.setAttribute("data-row-id", row.id);
        td.setAttribute("data-col-id", col.id);
        if (cell.type === "na") {
          td.innerHTML = `
            <div class="cell-inner cell-na" title="Right-click to restore">
              <span class="na-badge">N/A</span>
            </div>
          `;
        } else {
          const pct = cell.percentage ?? (cell.checked ? 100 : 0);
          const isChecked = Boolean(cell.checked);
          let pctData = "0";
          if (pct === 100) pctData = "100";
          else if (pct > 0) pctData = "partial";
          td.innerHTML = `
            <div class="cell-inner">
              <div class="cell-checkbox-wrapper">
                <input type="checkbox" class="cell-checkbox" ${isChecked ? "checked" : ""} data-row-id="${row.id}" data-col-id="${col.id}" title="Left click to toggle complete">
              </div>
              <div class="cell-percent-badge" data-pct="${pctData}" data-row-id="${row.id}" data-col-id="${col.id}" title="Click to adjust %">${pct}%</div>
            </div>
          `;
        }
        td.addEventListener("contextmenu", (e) => {
          e.preventDefault();
          closeActivePopover();
          manager.toggleCellNA(row.id, col.id);
        });
        tr.appendChild(td);
      });
      if (isEditMode) {
        const tdPlaceholder = document.createElement("td");
        tdPlaceholder.style.background = "transparent";
        tr.appendChild(tdPlaceholder);
      }
      tableBody.appendChild(tr);
    });
    renderMetrics();
    attachEventListeners();
  }
  function attachEventListeners() {
    document.querySelectorAll(".cell-checkbox").forEach((checkbox) => {
      checkbox.addEventListener("change", (e) => {
        const target = e.target;
        const rowId = target.getAttribute("data-row-id");
        const colId = target.getAttribute("data-col-id");
        manager.toggleCellChecked(rowId, colId, target.checked);
      });
    });
    document.querySelectorAll(".cell-percent-badge").forEach((badge) => {
      badge.addEventListener("click", (e) => {
        e.stopPropagation();
        closeActivePopover();
        const target = e.currentTarget;
        const rowId = target.getAttribute("data-row-id");
        const colId = target.getAttribute("data-col-id");
        const popover = document.createElement("div");
        popover.className = "percentage-popover";
        const percentages = [0, 25, 50, 75, 100];
        percentages.forEach((pct) => {
          const btn = document.createElement("button");
          btn.className = "pct-opt-btn";
          btn.textContent = `${pct}%`;
          btn.addEventListener("click", (pe) => {
            pe.stopPropagation();
            manager.setCellPercentage(rowId, colId, pct);
            closeActivePopover();
          });
          popover.appendChild(btn);
        });
        const rect = target.getBoundingClientRect();
        popover.style.position = "fixed";
        popover.style.top = `${rect.bottom + 4}px`;
        popover.style.left = `${Math.max(10, rect.left - 50)}px`;
        document.body.appendChild(popover);
        activePopover = popover;
      });
    });
    document.querySelectorAll('.col-title-text[contenteditable="true"]').forEach((el) => {
      el.addEventListener("blur", (e) => {
        const target = e.target;
        const colId = target.getAttribute("data-col-id");
        manager.renameColumn(colId, target.textContent || "");
      });
      el.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          e.target.blur();
        }
      });
    });
    document.querySelectorAll(".delete-col-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const target = e.currentTarget;
        const colId = target.getAttribute("data-col-id");
        if (confirm("Are you sure you want to delete this column?")) {
          manager.deleteColumn(colId);
          showToast("Column deleted", "info");
        }
      });
    });
    document.querySelectorAll('.track-name[contenteditable="true"]').forEach((el) => {
      el.addEventListener("blur", (e) => {
        const target = e.target;
        const rowId = target.getAttribute("data-row-id");
        manager.renameRow(rowId, target.textContent || "");
      });
      el.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          e.target.blur();
        }
      });
    });
    document.querySelectorAll('.track-badge[contenteditable="true"]').forEach((el) => {
      el.addEventListener("blur", (e) => {
        const target = e.target;
        const rowId = target.getAttribute("data-row-cat-id");
        manager.updateRowCategory(rowId, target.textContent || "");
      });
      el.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          e.target.blur();
        }
      });
    });
    document.querySelectorAll(".delete-row-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const target = e.currentTarget;
        const rowId = target.getAttribute("data-row-id");
        if (confirm("Are you sure you want to delete this row?")) {
          manager.deleteRow(rowId);
          showToast("Row deleted", "info");
        }
      });
    });
    const btnAddColHeader = document.getElementById("btn-add-col-header");
    if (btnAddColHeader) {
      btnAddColHeader.addEventListener("click", () => {
        manager.addColumn();
        showToast("New column added", "success");
      });
    }
  }
  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
  btnToggleEdit.addEventListener("click", () => {
    const isEdit = manager.toggleEditMode();
    showToast(isEdit ? "Visual Edit Mode enabled" : "Structure locked (View Mode)", "info");
  });
  btnAddCol.addEventListener("click", () => {
    manager.addColumn();
    showToast("New column added", "success");
  });
  btnAddRow.addEventListener("click", () => {
    manager.addRow();
    showToast("New track/row added", "success");
  });
  btnAddRowBottom.addEventListener("click", () => {
    manager.addRow();
    showToast("New track/row added", "success");
  });
  btnSaveDb.addEventListener("click", async () => {
    const success = await manager.persistData();
    if (success) {
      showToast("Roadmap saved to JSON database", "success");
    } else {
      showToast("Saved to local storage fallback", "info");
    }
  });
  btnExportJson.addEventListener("click", () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(manager.getData(), null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "roadmap-data.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast("Exported roadmap-data.json", "success");
  });
  inputImportJson.addEventListener("change", (e) => {
    const target = e.target;
    if (target.files && target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result;
        if (manager.loadFromJSON(content)) {
          showToast("Imported roadmap successfully", "success");
        } else {
          showToast("Invalid JSON file structure", "info");
        }
      };
      reader.readAsText(target.files[0]);
    }
  });
  btnResetDemo.addEventListener("click", () => {
    if (confirm("Reset roadmap back to demo template?")) {
      manager.resetToDefault();
      showToast("Roadmap reset to demo template", "info");
    }
  });
  manager.subscribe(() => {
    renderTable();
  });
  await manager.loadInitialData();
  renderTable();
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBSb2FkbWFwTWFuYWdlciB9IGZyb20gJy4vcm9hZG1hcCc7XG5cbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ0RPTUNvbnRlbnRMb2FkZWQnLCBhc3luYyAoKSA9PiB7XG4gIGNvbnN0IG1hbmFnZXIgPSBuZXcgUm9hZG1hcE1hbmFnZXIoKTtcblxuICAvLyBET00gRWxlbWVudHNcbiAgY29uc3QgdGFibGVIZWFkZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9hZG1hcC10YWJsZS1oZWFkZXInKSBhcyBIVE1MVGFibGVSb3dFbGVtZW50O1xuICBjb25zdCB0YWJsZUJvZHkgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9hZG1hcC10YWJsZS1ib2R5JykgYXMgSFRNTFRhYmxlU2VjdGlvbkVsZW1lbnQ7XG4gIFxuICBjb25zdCBidG5Ub2dnbGVFZGl0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2J0bi10b2dnbGUtZWRpdCcpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBlZGl0VG9nZ2xlTGFiZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZWRpdC10b2dnbGUtbGFiZWwnKSBhcyBIVE1MU3BhbkVsZW1lbnQ7XG4gIFxuICBjb25zdCBidG5BZGRDb2wgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYnRuLWFkZC1jb2wnKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbiAgY29uc3QgYnRuQWRkUm93ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2J0bi1hZGQtcm93JykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IGJ0bkFkZFJvd0JvdHRvbSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdidG4tYWRkLXJvdy1ib3R0b20nKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbiAgXG4gIGNvbnN0IGJ0blNhdmVEYiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdidG4tc2F2ZS1kYicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBidG5FeHBvcnRKc29uID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2J0bi1leHBvcnQtanNvbicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBpbnB1dEltcG9ydEpzb24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnaW5wdXQtaW1wb3J0LWpzb24nKSBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICBjb25zdCBidG5SZXNldERlbW8gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYnRuLXJlc2V0LWRlbW8nKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcblxuICBjb25zdCBtZXRyaWNPdmVyYWxsUGN0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ21ldHJpYy1vdmVyYWxsLXBjdCcpIGFzIEhUTUxFbGVtZW50O1xuICBjb25zdCBwcm9ncmVzc0JhckZpbGwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncHJvZ3Jlc3MtYmFyLWZpbGwnKSBhcyBIVE1MRWxlbWVudDtcbiAgY29uc3QgbWV0cmljQ29tcGxldGVkQ291bnQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbWV0cmljLWNvbXBsZXRlZC1jb3VudCcpIGFzIEhUTUxFbGVtZW50O1xuICBjb25zdCBtZXRyaWNSb3dzQ291bnQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbWV0cmljLXJvd3MtY291bnQnKSBhcyBIVE1MRWxlbWVudDtcbiAgY29uc3QgdG9hc3RDb250YWluZXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndG9hc3QtY29udGFpbmVyJykgYXMgSFRNTEVsZW1lbnQ7XG5cbiAgLy8gQWN0aXZlIHBvcG92ZXIgdHJhY2tlclxuICBsZXQgYWN0aXZlUG9wb3ZlcjogSFRNTEVsZW1lbnQgfCBudWxsID0gbnVsbDtcblxuICBmdW5jdGlvbiBzaG93VG9hc3QobWVzc2FnZTogc3RyaW5nLCB0eXBlOiAnc3VjY2VzcycgfCAnaW5mbycgPSAnc3VjY2VzcycpIHtcbiAgICBjb25zdCB0b2FzdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHRvYXN0LmNsYXNzTmFtZSA9IGB0b2FzdCAke3R5cGV9YDtcbiAgICB0b2FzdC5pbm5lckhUTUwgPSBgPHNwYW4+JHt0eXBlID09PSAnc3VjY2VzcycgPyAn4pyFJyA6ICfihLnvuI8nfTwvc3Bhbj48c3Bhbj4ke21lc3NhZ2V9PC9zcGFuPmA7XG4gICAgdG9hc3RDb250YWluZXIuYXBwZW5kQ2hpbGQodG9hc3QpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdG9hc3Quc3R5bGUub3BhY2l0eSA9ICcwJztcbiAgICAgIHRvYXN0LnN0eWxlLnRyYW5zZm9ybSA9ICd0cmFuc2xhdGVZKDEwcHgpJztcbiAgICAgIHRvYXN0LnN0eWxlLnRyYW5zaXRpb24gPSAnYWxsIDAuM3MgZWFzZSc7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHRvYXN0LnJlbW92ZSgpLCAzMDApO1xuICAgIH0sIDI4MDApO1xuICB9XG5cbiAgZnVuY3Rpb24gY2xvc2VBY3RpdmVQb3BvdmVyKCkge1xuICAgIGlmIChhY3RpdmVQb3BvdmVyKSB7XG4gICAgICBhY3RpdmVQb3BvdmVyLnJlbW92ZSgpO1xuICAgICAgYWN0aXZlUG9wb3ZlciA9IG51bGw7XG4gICAgfVxuICB9XG5cbiAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZSkgPT4ge1xuICAgIGlmIChhY3RpdmVQb3BvdmVyICYmICFhY3RpdmVQb3BvdmVyLmNvbnRhaW5zKGUudGFyZ2V0IGFzIE5vZGUpKSB7XG4gICAgICBjbG9zZUFjdGl2ZVBvcG92ZXIoKTtcbiAgICB9XG4gIH0pO1xuXG4gIGZ1bmN0aW9uIHJlbmRlck1ldHJpY3MoKSB7XG4gICAgY29uc3QgbWV0cmljcyA9IG1hbmFnZXIuZ2V0TWV0cmljcygpO1xuICAgIG1ldHJpY092ZXJhbGxQY3QudGV4dENvbnRlbnQgPSBgJHttZXRyaWNzLm92ZXJhbGxQY3R9JWA7XG4gICAgcHJvZ3Jlc3NCYXJGaWxsLnN0eWxlLndpZHRoID0gYCR7bWV0cmljcy5vdmVyYWxsUGN0fSVgO1xuICAgIG1ldHJpY0NvbXBsZXRlZENvdW50LnRleHRDb250ZW50ID0gYCR7bWV0cmljcy5jb21wbGV0ZWRDZWxsc30gLyAke21ldHJpY3MudG90YWxBY3RpdmVDZWxsc31gO1xuICAgIG1ldHJpY1Jvd3NDb3VudC50ZXh0Q29udGVudCA9IGAke21ldHJpY3MudG90YWxSb3dzfWA7XG4gIH1cblxuICBmdW5jdGlvbiByZW5kZXJUYWJsZSgpIHtcbiAgICBjb25zdCBkYXRhID0gbWFuYWdlci5nZXREYXRhKCk7XG4gICAgY29uc3QgaXNFZGl0TW9kZSA9IG1hbmFnZXIuZ2V0RWRpdE1vZGUoKTtcblxuICAgIC8vIFRvZ2dsZSBlZGl0LW1vZGUgY2xhc3Mgb24gYm9keVxuICAgIGlmIChpc0VkaXRNb2RlKSB7XG4gICAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5hZGQoJ2VkaXQtbW9kZScpO1xuICAgICAgYnRuVG9nZ2xlRWRpdC5jbGFzc0xpc3QuYWRkKCdhY3RpdmUnKTtcbiAgICAgIGVkaXRUb2dnbGVMYWJlbC50ZXh0Q29udGVudCA9ICdMb2NrIFN0cnVjdHVyZSAoVmlldyBNb2RlKSc7XG4gICAgfSBlbHNlIHtcbiAgICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnJlbW92ZSgnZWRpdC1tb2RlJyk7XG4gICAgICBidG5Ub2dnbGVFZGl0LmNsYXNzTGlzdC5yZW1vdmUoJ2FjdGl2ZScpO1xuICAgICAgZWRpdFRvZ2dsZUxhYmVsLnRleHRDb250ZW50ID0gJ0VkaXQgVGFibGUgU3RydWN0dXJlJztcbiAgICB9XG5cbiAgICAvLyAxLiBSZW5kZXIgSGVhZGVyXG4gICAgdGFibGVIZWFkZXIuaW5uZXJIVE1MID0gJyc7XG5cbiAgICAvLyBGaXJzdCBjb2x1bW46IFRyYWNrIC8gRmVhdHVyZSBOYW1lXG4gICAgY29uc3QgdGhUcmFjayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3RoJyk7XG4gICAgdGhUcmFjay5jbGFzc05hbWUgPSAndHJhY2stY29sLWhlYWRlcic7XG4gICAgdGhUcmFjay5pbm5lckhUTUwgPSBgXG4gICAgICA8ZGl2IGNsYXNzPVwiY29sLWhlYWRlci1jb250ZW50XCI+XG4gICAgICAgIDxzcGFuPkZlYXR1cmUgLyBXb3JrIFRyYWNrPC9zcGFuPlxuICAgICAgPC9kaXY+XG4gICAgYDtcbiAgICB0YWJsZUhlYWRlci5hcHBlbmRDaGlsZCh0aFRyYWNrKTtcblxuICAgIC8vIER5bmFtaWMgQ29sdW1uc1xuICAgIGRhdGEuY29sdW1ucy5mb3JFYWNoKChjb2wpID0+IHtcbiAgICAgIGNvbnN0IHRoID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndGgnKTtcbiAgICAgIHRoLnNldEF0dHJpYnV0ZSgnZGF0YS1jb2wtaWQnLCBjb2wuaWQpO1xuICAgICAgXG4gICAgICBpZiAoaXNFZGl0TW9kZSkge1xuICAgICAgICB0aC5pbm5lckhUTUwgPSBgXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1oZWFkZXItY29udGVudFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJjb2wtdGl0bGUtdGV4dFwiIGNvbnRlbnRlZGl0YWJsZT1cInRydWVcIiBkYXRhLWNvbC1pZD1cIiR7Y29sLmlkfVwiPiR7ZXNjYXBlSHRtbChjb2wudGl0bGUpfTwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtYWN0aW9uc1wiPlxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuLWljb24gYnRuLWRhbmdlciBkZWxldGUtY29sLWJ0blwiIGRhdGEtY29sLWlkPVwiJHtjb2wuaWR9XCIgdGl0bGU9XCJEZWxldGUgY29sdW1uXCI+8J+Xke+4jzwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIGA7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aC5pbm5lckhUTUwgPSBgXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1oZWFkZXItY29udGVudFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJjb2wtdGl0bGUtdGV4dFwiPiR7ZXNjYXBlSHRtbChjb2wudGl0bGUpfTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgYDtcbiAgICAgIH1cbiAgICAgIHRhYmxlSGVhZGVyLmFwcGVuZENoaWxkKHRoKTtcbiAgICB9KTtcblxuICAgIC8vIFBsdXMgQWRkIENvbHVtbiBidXR0b24gb24gaGVhZGVyIHJvdyBpbiBFZGl0IE1vZGVcbiAgICBpZiAoaXNFZGl0TW9kZSkge1xuICAgICAgY29uc3QgdGhBZGQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCd0aCcpO1xuICAgICAgdGhBZGQuc3R5bGUud2lkdGggPSAnMTQwcHgnO1xuICAgICAgdGhBZGQuaW5uZXJIVE1MID0gYFxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYWRkLWNvbC1oZWFkZXItYnRuXCIgaWQ9XCJidG4tYWRkLWNvbC1oZWFkZXJcIj5cbiAgICAgICAgICDinpUgQWRkIENvbHVtblxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIGA7XG4gICAgICB0YWJsZUhlYWRlci5hcHBlbmRDaGlsZCh0aEFkZCk7XG4gICAgfVxuXG4gICAgLy8gMi4gUmVuZGVyIFJvd3MgJiBDZWxsc1xuICAgIHRhYmxlQm9keS5pbm5lckhUTUwgPSAnJztcblxuICAgIGRhdGEucm93cy5mb3JFYWNoKChyb3cpID0+IHtcbiAgICAgIGNvbnN0IHRyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndHInKTtcbiAgICAgIHRyLnNldEF0dHJpYnV0ZSgnZGF0YS1yb3ctaWQnLCByb3cuaWQpO1xuXG4gICAgICAvLyBUcmFjayBUaXRsZSBDZWxsXG4gICAgICBjb25zdCB0ZFRyYWNrID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndGQnKTtcbiAgICAgIHRkVHJhY2suY2xhc3NOYW1lID0gJ3RyYWNrLWNlbGwnO1xuICAgICAgXG4gICAgICBpZiAoaXNFZGl0TW9kZSkge1xuICAgICAgICB0ZFRyYWNrLmlubmVySFRNTCA9IGBcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwidHJhY2stY29udGVudFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRyYWNrLWluZm9cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0cmFjay1uYW1lXCIgY29udGVudGVkaXRhYmxlPVwidHJ1ZVwiIGRhdGEtcm93LWlkPVwiJHtyb3cuaWR9XCI+JHtlc2NhcGVIdG1sKHJvdy50aXRsZSl9PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRyYWNrLWJhZGdlXCIgY29udGVudGVkaXRhYmxlPVwidHJ1ZVwiIGRhdGEtcm93LWNhdC1pZD1cIiR7cm93LmlkfVwiPiR7ZXNjYXBlSHRtbChyb3cuY2F0ZWdvcnkgfHwgJ0ZlYXR1cmUnKX08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0cmFjay1hY3Rpb25zXCI+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4taWNvbiBidG4tZGFuZ2VyIGRlbGV0ZS1yb3ctYnRuXCIgZGF0YS1yb3ctaWQ9XCIke3Jvdy5pZH1cIiB0aXRsZT1cIkRlbGV0ZSByb3dcIj7wn5eR77iPPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgYDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRkVHJhY2suaW5uZXJIVE1MID0gYFxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0cmFjay1jb250ZW50XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidHJhY2staW5mb1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRyYWNrLW5hbWVcIj4ke2VzY2FwZUh0bWwocm93LnRpdGxlKX08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidHJhY2stYmFkZ2VcIj4ke2VzY2FwZUh0bWwocm93LmNhdGVnb3J5IHx8ICdGZWF0dXJlJyl9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIGA7XG4gICAgICB9XG4gICAgICB0ci5hcHBlbmRDaGlsZCh0ZFRyYWNrKTtcblxuICAgICAgLy8gRHluYW1pYyBDZWxsc1xuICAgICAgZGF0YS5jb2x1bW5zLmZvckVhY2goKGNvbCkgPT4ge1xuICAgICAgICBjb25zdCBjZWxsID0gcm93LmNlbGxzW2NvbC5pZF0gfHwgeyB0eXBlOiAnYWN0aXZlJywgY2hlY2tlZDogZmFsc2UsIHBlcmNlbnRhZ2U6IDAgfTtcbiAgICAgICAgY29uc3QgdGQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCd0ZCcpO1xuICAgICAgICB0ZC5jbGFzc05hbWUgPSAncm9hZG1hcC1jZWxsJztcbiAgICAgICAgdGQuc2V0QXR0cmlidXRlKCdkYXRhLXJvdy1pZCcsIHJvdy5pZCk7XG4gICAgICAgIHRkLnNldEF0dHJpYnV0ZSgnZGF0YS1jb2wtaWQnLCBjb2wuaWQpO1xuXG4gICAgICAgIGlmIChjZWxsLnR5cGUgPT09ICduYScpIHtcbiAgICAgICAgICAvLyBOL0EgQ2VsbFxuICAgICAgICAgIHRkLmlubmVySFRNTCA9IGBcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjZWxsLWlubmVyIGNlbGwtbmFcIiB0aXRsZT1cIlJpZ2h0LWNsaWNrIHRvIHJlc3RvcmVcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJuYS1iYWRnZVwiPk4vQTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIGA7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gQWN0aXZlIENlbGwgKENoZWNrYm94ICsgUGVyY2VudGFnZSBiYWRnZSBpbiBjb3JuZXIpXG4gICAgICAgICAgY29uc3QgcGN0ID0gY2VsbC5wZXJjZW50YWdlID8/IChjZWxsLmNoZWNrZWQgPyAxMDAgOiAwKTtcbiAgICAgICAgICBjb25zdCBpc0NoZWNrZWQgPSBCb29sZWFuKGNlbGwuY2hlY2tlZCk7XG4gICAgICAgICAgXG4gICAgICAgICAgbGV0IHBjdERhdGEgPSAnMCc7XG4gICAgICAgICAgaWYgKHBjdCA9PT0gMTAwKSBwY3REYXRhID0gJzEwMCc7XG4gICAgICAgICAgZWxzZSBpZiAocGN0ID4gMCkgcGN0RGF0YSA9ICdwYXJ0aWFsJztcblxuICAgICAgICAgIHRkLmlubmVySFRNTCA9IGBcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjZWxsLWlubmVyXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjZWxsLWNoZWNrYm94LXdyYXBwZXJcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2xhc3M9XCJjZWxsLWNoZWNrYm94XCIgJHtpc0NoZWNrZWQgPyAnY2hlY2tlZCcgOiAnJ30gZGF0YS1yb3ctaWQ9XCIke3Jvdy5pZH1cIiBkYXRhLWNvbC1pZD1cIiR7Y29sLmlkfVwiIHRpdGxlPVwiTGVmdCBjbGljayB0byB0b2dnbGUgY29tcGxldGVcIj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjZWxsLXBlcmNlbnQtYmFkZ2VcIiBkYXRhLXBjdD1cIiR7cGN0RGF0YX1cIiBkYXRhLXJvdy1pZD1cIiR7cm93LmlkfVwiIGRhdGEtY29sLWlkPVwiJHtjb2wuaWR9XCIgdGl0bGU9XCJDbGljayB0byBhZGp1c3QgJVwiPiR7cGN0fSU8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIGA7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBDb250ZXh0IE1lbnUgKFJpZ2h0IENsaWNrKSB0byB0b2dnbGUgTi9BIHN0YXRlXG4gICAgICAgIHRkLmFkZEV2ZW50TGlzdGVuZXIoJ2NvbnRleHRtZW51JywgKGUpID0+IHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgY2xvc2VBY3RpdmVQb3BvdmVyKCk7XG4gICAgICAgICAgbWFuYWdlci50b2dnbGVDZWxsTkEocm93LmlkLCBjb2wuaWQpO1xuICAgICAgICB9KTtcblxuICAgICAgICB0ci5hcHBlbmRDaGlsZCh0ZCk7XG4gICAgICB9KTtcblxuICAgICAgLy8gRW1wdHkgY2VsbCB0byBiYWxhbmNlIHRoZSBcIkFkZCBDb2x1bW5cIiBoZWFkZXIgd2hlbiBpbiBlZGl0IG1vZGVcbiAgICAgIGlmIChpc0VkaXRNb2RlKSB7XG4gICAgICAgIGNvbnN0IHRkUGxhY2Vob2xkZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCd0ZCcpO1xuICAgICAgICB0ZFBsYWNlaG9sZGVyLnN0eWxlLmJhY2tncm91bmQgPSAndHJhbnNwYXJlbnQnO1xuICAgICAgICB0ci5hcHBlbmRDaGlsZCh0ZFBsYWNlaG9sZGVyKTtcbiAgICAgIH1cblxuICAgICAgdGFibGVCb2R5LmFwcGVuZENoaWxkKHRyKTtcbiAgICB9KTtcblxuICAgIHJlbmRlck1ldHJpY3MoKTtcbiAgICBhdHRhY2hFdmVudExpc3RlbmVycygpO1xuICB9XG5cbiAgZnVuY3Rpb24gYXR0YWNoRXZlbnRMaXN0ZW5lcnMoKSB7XG4gICAgLy8gQ2hlY2tib3ggdG9nZ2xpbmdcbiAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuY2VsbC1jaGVja2JveCcpLmZvckVhY2goKGNoZWNrYm94KSA9PiB7XG4gICAgICBjaGVja2JveC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoZSkgPT4ge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICAgICAgICBjb25zdCByb3dJZCA9IHRhcmdldC5nZXRBdHRyaWJ1dGUoJ2RhdGEtcm93LWlkJykhO1xuICAgICAgICBjb25zdCBjb2xJZCA9IHRhcmdldC5nZXRBdHRyaWJ1dGUoJ2RhdGEtY29sLWlkJykhO1xuICAgICAgICBtYW5hZ2VyLnRvZ2dsZUNlbGxDaGVja2VkKHJvd0lkLCBjb2xJZCwgdGFyZ2V0LmNoZWNrZWQpO1xuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICAvLyBQZXJjZW50YWdlIGJhZGdlIGNsaWNrIGZvciBxdWljayBzZWxlY3Rpb24gcG9wb3ZlclxuICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy5jZWxsLXBlcmNlbnQtYmFkZ2UnKS5mb3JFYWNoKChiYWRnZSkgPT4ge1xuICAgICAgYmFkZ2UuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZSkgPT4ge1xuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICBjbG9zZUFjdGl2ZVBvcG92ZXIoKTtcblxuICAgICAgICBjb25zdCB0YXJnZXQgPSBlLmN1cnJlbnRUYXJnZXQgYXMgSFRNTEVsZW1lbnQ7XG4gICAgICAgIGNvbnN0IHJvd0lkID0gdGFyZ2V0LmdldEF0dHJpYnV0ZSgnZGF0YS1yb3ctaWQnKSE7XG4gICAgICAgIGNvbnN0IGNvbElkID0gdGFyZ2V0LmdldEF0dHJpYnV0ZSgnZGF0YS1jb2wtaWQnKSE7XG5cbiAgICAgICAgY29uc3QgcG9wb3ZlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgICBwb3BvdmVyLmNsYXNzTmFtZSA9ICdwZXJjZW50YWdlLXBvcG92ZXInO1xuXG4gICAgICAgIGNvbnN0IHBlcmNlbnRhZ2VzID0gWzAsIDI1LCA1MCwgNzUsIDEwMF07XG4gICAgICAgIHBlcmNlbnRhZ2VzLmZvckVhY2goKHBjdCkgPT4ge1xuICAgICAgICAgIGNvbnN0IGJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgICAgICAgIGJ0bi5jbGFzc05hbWUgPSAncGN0LW9wdC1idG4nO1xuICAgICAgICAgIGJ0bi50ZXh0Q29udGVudCA9IGAke3BjdH0lYDtcbiAgICAgICAgICBidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAocGUpID0+IHtcbiAgICAgICAgICAgIHBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgbWFuYWdlci5zZXRDZWxsUGVyY2VudGFnZShyb3dJZCwgY29sSWQsIHBjdCk7XG4gICAgICAgICAgICBjbG9zZUFjdGl2ZVBvcG92ZXIoKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBwb3BvdmVyLmFwcGVuZENoaWxkKGJ0bik7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIFBvc2l0aW9uIHBvcG92ZXIgcmVsYXRpdmUgdG8gYmFkZ2VcbiAgICAgICAgY29uc3QgcmVjdCA9IHRhcmdldC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgcG9wb3Zlci5zdHlsZS5wb3NpdGlvbiA9ICdmaXhlZCc7XG4gICAgICAgIHBvcG92ZXIuc3R5bGUudG9wID0gYCR7cmVjdC5ib3R0b20gKyA0fXB4YDtcbiAgICAgICAgcG9wb3Zlci5zdHlsZS5sZWZ0ID0gYCR7TWF0aC5tYXgoMTAsIHJlY3QubGVmdCAtIDUwKX1weGA7XG5cbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChwb3BvdmVyKTtcbiAgICAgICAgYWN0aXZlUG9wb3ZlciA9IHBvcG92ZXI7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIC8vIENvbHVtbiByZW5hbWUgKGNvbnRlbnRlZGl0YWJsZSBibHVyIC8gZW50ZXIga2V5KVxuICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy5jb2wtdGl0bGUtdGV4dFtjb250ZW50ZWRpdGFibGU9XCJ0cnVlXCJdJykuZm9yRWFjaCgoZWwpID0+IHtcbiAgICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoJ2JsdXInLCAoZSkgPT4ge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBlLnRhcmdldCBhcyBIVE1MRWxlbWVudDtcbiAgICAgICAgY29uc3QgY29sSWQgPSB0YXJnZXQuZ2V0QXR0cmlidXRlKCdkYXRhLWNvbC1pZCcpITtcbiAgICAgICAgbWFuYWdlci5yZW5hbWVDb2x1bW4oY29sSWQsIHRhcmdldC50ZXh0Q29udGVudCB8fCAnJyk7XG4gICAgICB9KTtcbiAgICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCAoZSkgPT4ge1xuICAgICAgICBpZiAoKGUgYXMgS2V5Ym9hcmRFdmVudCkua2V5ID09PSAnRW50ZXInKSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkuYmx1cigpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIC8vIERlbGV0ZSBjb2x1bW5cbiAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuZGVsZXRlLWNvbC1idG4nKS5mb3JFYWNoKChidG4pID0+IHtcbiAgICAgIGJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlKSA9PiB7XG4gICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGUuY3VycmVudFRhcmdldCBhcyBIVE1MRWxlbWVudDtcbiAgICAgICAgY29uc3QgY29sSWQgPSB0YXJnZXQuZ2V0QXR0cmlidXRlKCdkYXRhLWNvbC1pZCcpITtcbiAgICAgICAgaWYgKGNvbmZpcm0oJ0FyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgdGhpcyBjb2x1bW4/JykpIHtcbiAgICAgICAgICBtYW5hZ2VyLmRlbGV0ZUNvbHVtbihjb2xJZCk7XG4gICAgICAgICAgc2hvd1RvYXN0KCdDb2x1bW4gZGVsZXRlZCcsICdpbmZvJyk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgLy8gUm93IHJlbmFtZVxuICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy50cmFjay1uYW1lW2NvbnRlbnRlZGl0YWJsZT1cInRydWVcIl0nKS5mb3JFYWNoKChlbCkgPT4ge1xuICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignYmx1cicsIChlKSA9PiB7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50O1xuICAgICAgICBjb25zdCByb3dJZCA9IHRhcmdldC5nZXRBdHRyaWJ1dGUoJ2RhdGEtcm93LWlkJykhO1xuICAgICAgICBtYW5hZ2VyLnJlbmFtZVJvdyhyb3dJZCwgdGFyZ2V0LnRleHRDb250ZW50IHx8ICcnKTtcbiAgICAgIH0pO1xuICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIChlKSA9PiB7XG4gICAgICAgIGlmICgoZSBhcyBLZXlib2FyZEV2ZW50KS5rZXkgPT09ICdFbnRlcicpIHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgKGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50KS5ibHVyKCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgLy8gUm93IENhdGVnb3J5IHJlbmFtZVxuICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy50cmFjay1iYWRnZVtjb250ZW50ZWRpdGFibGU9XCJ0cnVlXCJdJykuZm9yRWFjaCgoZWwpID0+IHtcbiAgICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoJ2JsdXInLCAoZSkgPT4ge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBlLnRhcmdldCBhcyBIVE1MRWxlbWVudDtcbiAgICAgICAgY29uc3Qgcm93SWQgPSB0YXJnZXQuZ2V0QXR0cmlidXRlKCdkYXRhLXJvdy1jYXQtaWQnKSE7XG4gICAgICAgIG1hbmFnZXIudXBkYXRlUm93Q2F0ZWdvcnkocm93SWQsIHRhcmdldC50ZXh0Q29udGVudCB8fCAnJyk7XG4gICAgICB9KTtcbiAgICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCAoZSkgPT4ge1xuICAgICAgICBpZiAoKGUgYXMgS2V5Ym9hcmRFdmVudCkua2V5ID09PSAnRW50ZXInKSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkuYmx1cigpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIC8vIERlbGV0ZSByb3dcbiAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuZGVsZXRlLXJvdy1idG4nKS5mb3JFYWNoKChidG4pID0+IHtcbiAgICAgIGJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlKSA9PiB7XG4gICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGUuY3VycmVudFRhcmdldCBhcyBIVE1MRWxlbWVudDtcbiAgICAgICAgY29uc3Qgcm93SWQgPSB0YXJnZXQuZ2V0QXR0cmlidXRlKCdkYXRhLXJvdy1pZCcpITtcbiAgICAgICAgaWYgKGNvbmZpcm0oJ0FyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgdGhpcyByb3c/JykpIHtcbiAgICAgICAgICBtYW5hZ2VyLmRlbGV0ZVJvdyhyb3dJZCk7XG4gICAgICAgICAgc2hvd1RvYXN0KCdSb3cgZGVsZXRlZCcsICdpbmZvJyk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgLy8gSGVhZGVyIEFkZCBDb2x1bW4gYnV0dG9uXG4gICAgY29uc3QgYnRuQWRkQ29sSGVhZGVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2J0bi1hZGQtY29sLWhlYWRlcicpO1xuICAgIGlmIChidG5BZGRDb2xIZWFkZXIpIHtcbiAgICAgIGJ0bkFkZENvbEhlYWRlci5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICAgICAgbWFuYWdlci5hZGRDb2x1bW4oKTtcbiAgICAgICAgc2hvd1RvYXN0KCdOZXcgY29sdW1uIGFkZGVkJywgJ3N1Y2Nlc3MnKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIGVzY2FwZUh0bWwoc3RyOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGNvbnN0IGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGRpdi50ZXh0Q29udGVudCA9IHN0cjtcbiAgICByZXR1cm4gZGl2LmlubmVySFRNTDtcbiAgfVxuXG4gIC8vIEV2ZW50IExpc3RlbmVycyBmb3IgVG9wIFRvb2xiYXIgQnV0dG9uc1xuICBidG5Ub2dnbGVFZGl0LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGNvbnN0IGlzRWRpdCA9IG1hbmFnZXIudG9nZ2xlRWRpdE1vZGUoKTtcbiAgICBzaG93VG9hc3QoaXNFZGl0ID8gJ1Zpc3VhbCBFZGl0IE1vZGUgZW5hYmxlZCcgOiAnU3RydWN0dXJlIGxvY2tlZCAoVmlldyBNb2RlKScsICdpbmZvJyk7XG4gIH0pO1xuXG4gIGJ0bkFkZENvbC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBtYW5hZ2VyLmFkZENvbHVtbigpO1xuICAgIHNob3dUb2FzdCgnTmV3IGNvbHVtbiBhZGRlZCcsICdzdWNjZXNzJyk7XG4gIH0pO1xuXG4gIGJ0bkFkZFJvdy5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBtYW5hZ2VyLmFkZFJvdygpO1xuICAgIHNob3dUb2FzdCgnTmV3IHRyYWNrL3JvdyBhZGRlZCcsICdzdWNjZXNzJyk7XG4gIH0pO1xuXG4gIGJ0bkFkZFJvd0JvdHRvbS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBtYW5hZ2VyLmFkZFJvdygpO1xuICAgIHNob3dUb2FzdCgnTmV3IHRyYWNrL3JvdyBhZGRlZCcsICdzdWNjZXNzJyk7XG4gIH0pO1xuXG4gIGJ0blNhdmVEYi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBzdWNjZXNzID0gYXdhaXQgbWFuYWdlci5wZXJzaXN0RGF0YSgpO1xuICAgIGlmIChzdWNjZXNzKSB7XG4gICAgICBzaG93VG9hc3QoJ1JvYWRtYXAgc2F2ZWQgdG8gSlNPTiBkYXRhYmFzZScsICdzdWNjZXNzJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNob3dUb2FzdCgnU2F2ZWQgdG8gbG9jYWwgc3RvcmFnZSBmYWxsYmFjaycsICdpbmZvJyk7XG4gICAgfVxuICB9KTtcblxuICBidG5FeHBvcnRKc29uLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGNvbnN0IGRhdGFTdHIgPSAnZGF0YTp0ZXh0L2pzb247Y2hhcnNldD11dGYtOCwnICsgZW5jb2RlVVJJQ29tcG9uZW50KEpTT04uc3RyaW5naWZ5KG1hbmFnZXIuZ2V0RGF0YSgpLCBudWxsLCAyKSk7XG4gICAgY29uc3QgZG93bmxvYWRBbmNob3IgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgZG93bmxvYWRBbmNob3Iuc2V0QXR0cmlidXRlKCdocmVmJywgZGF0YVN0cik7XG4gICAgZG93bmxvYWRBbmNob3Iuc2V0QXR0cmlidXRlKCdkb3dubG9hZCcsICdyb2FkbWFwLWRhdGEuanNvbicpO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZG93bmxvYWRBbmNob3IpO1xuICAgIGRvd25sb2FkQW5jaG9yLmNsaWNrKCk7XG4gICAgZG93bmxvYWRBbmNob3IucmVtb3ZlKCk7XG4gICAgc2hvd1RvYXN0KCdFeHBvcnRlZCByb2FkbWFwLWRhdGEuanNvbicsICdzdWNjZXNzJyk7XG4gIH0pO1xuXG4gIGlucHV0SW1wb3J0SnNvbi5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoZSkgPT4ge1xuICAgIGNvbnN0IHRhcmdldCA9IGUudGFyZ2V0IGFzIEhUTUxJbnB1dEVsZW1lbnQ7XG4gICAgaWYgKHRhcmdldC5maWxlcyAmJiB0YXJnZXQuZmlsZXNbMF0pIHtcbiAgICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG4gICAgICByZWFkZXIub25sb2FkID0gKGV2ZW50KSA9PiB7XG4gICAgICAgIGNvbnN0IGNvbnRlbnQgPSBldmVudC50YXJnZXQ/LnJlc3VsdCBhcyBzdHJpbmc7XG4gICAgICAgIGlmIChtYW5hZ2VyLmxvYWRGcm9tSlNPTihjb250ZW50KSkge1xuICAgICAgICAgIHNob3dUb2FzdCgnSW1wb3J0ZWQgcm9hZG1hcCBzdWNjZXNzZnVsbHknLCAnc3VjY2VzcycpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNob3dUb2FzdCgnSW52YWxpZCBKU09OIGZpbGUgc3RydWN0dXJlJywgJ2luZm8nKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIHJlYWRlci5yZWFkQXNUZXh0KHRhcmdldC5maWxlc1swXSk7XG4gICAgfVxuICB9KTtcblxuICBidG5SZXNldERlbW8uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgaWYgKGNvbmZpcm0oJ1Jlc2V0IHJvYWRtYXAgYmFjayB0byBkZW1vIHRlbXBsYXRlPycpKSB7XG4gICAgICBtYW5hZ2VyLnJlc2V0VG9EZWZhdWx0KCk7XG4gICAgICBzaG93VG9hc3QoJ1JvYWRtYXAgcmVzZXQgdG8gZGVtbyB0ZW1wbGF0ZScsICdpbmZvJyk7XG4gICAgfVxuICB9KTtcblxuICAvLyBTdWJzY3JpYmUgdG8gbW9kZWwgY2hhbmdlcyB0byB0cmlnZ2VyIHJlLXJlbmRlcnNcbiAgbWFuYWdlci5zdWJzY3JpYmUoKCkgPT4ge1xuICAgIHJlbmRlclRhYmxlKCk7XG4gIH0pO1xuXG4gIC8vIExvYWQgaW5pdGlhbCBkYXRhXG4gIGF3YWl0IG1hbmFnZXIubG9hZEluaXRpYWxEYXRhKCk7XG4gIHJlbmRlclRhYmxlKCk7XG59KTtcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0I7QUFFL0IsU0FBUyxpQkFBaUIsb0JBQW9CLFlBQVk7QUFDeEQsUUFBTSxVQUFVLElBQUksZUFBZTtBQUduQyxRQUFNLGNBQWMsU0FBUyxlQUFlLHNCQUFzQjtBQUNsRSxRQUFNLFlBQVksU0FBUyxlQUFlLG9CQUFvQjtBQUU5RCxRQUFNLGdCQUFnQixTQUFTLGVBQWUsaUJBQWlCO0FBQy9ELFFBQU0sa0JBQWtCLFNBQVMsZUFBZSxtQkFBbUI7QUFFbkUsUUFBTSxZQUFZLFNBQVMsZUFBZSxhQUFhO0FBQ3ZELFFBQU0sWUFBWSxTQUFTLGVBQWUsYUFBYTtBQUN2RCxRQUFNLGtCQUFrQixTQUFTLGVBQWUsb0JBQW9CO0FBRXBFLFFBQU0sWUFBWSxTQUFTLGVBQWUsYUFBYTtBQUN2RCxRQUFNLGdCQUFnQixTQUFTLGVBQWUsaUJBQWlCO0FBQy9ELFFBQU0sa0JBQWtCLFNBQVMsZUFBZSxtQkFBbUI7QUFDbkUsUUFBTSxlQUFlLFNBQVMsZUFBZSxnQkFBZ0I7QUFFN0QsUUFBTSxtQkFBbUIsU0FBUyxlQUFlLG9CQUFvQjtBQUNyRSxRQUFNLGtCQUFrQixTQUFTLGVBQWUsbUJBQW1CO0FBQ25FLFFBQU0sdUJBQXVCLFNBQVMsZUFBZSx3QkFBd0I7QUFDN0UsUUFBTSxrQkFBa0IsU0FBUyxlQUFlLG1CQUFtQjtBQUNuRSxRQUFNLGlCQUFpQixTQUFTLGVBQWUsaUJBQWlCO0FBR2hFLE1BQUksZ0JBQW9DO0FBRXhDLFdBQVMsVUFBVSxTQUFpQixPQUEyQixXQUFXO0FBQ3hFLFVBQU0sUUFBUSxTQUFTLGNBQWMsS0FBSztBQUMxQyxVQUFNLFlBQVksU0FBUyxJQUFJO0FBQy9CLFVBQU0sWUFBWSxTQUFTLFNBQVMsWUFBWSxNQUFNLElBQUksZ0JBQWdCLE9BQU87QUFDakYsbUJBQWUsWUFBWSxLQUFLO0FBQ2hDLGVBQVcsTUFBTTtBQUNmLFlBQU0sTUFBTSxVQUFVO0FBQ3RCLFlBQU0sTUFBTSxZQUFZO0FBQ3hCLFlBQU0sTUFBTSxhQUFhO0FBQ3pCLGlCQUFXLE1BQU0sTUFBTSxPQUFPLEdBQUcsR0FBRztBQUFBLElBQ3RDLEdBQUcsSUFBSTtBQUFBLEVBQ1Q7QUFFQSxXQUFTLHFCQUFxQjtBQUM1QixRQUFJLGVBQWU7QUFDakIsb0JBQWMsT0FBTztBQUNyQixzQkFBZ0I7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUN4QyxRQUFJLGlCQUFpQixDQUFDLGNBQWMsU0FBUyxFQUFFLE1BQWMsR0FBRztBQUM5RCx5QkFBbUI7QUFBQSxJQUNyQjtBQUFBLEVBQ0YsQ0FBQztBQUVELFdBQVMsZ0JBQWdCO0FBQ3ZCLFVBQU0sVUFBVSxRQUFRLFdBQVc7QUFDbkMscUJBQWlCLGNBQWMsR0FBRyxRQUFRLFVBQVU7QUFDcEQsb0JBQWdCLE1BQU0sUUFBUSxHQUFHLFFBQVEsVUFBVTtBQUNuRCx5QkFBcUIsY0FBYyxHQUFHLFFBQVEsY0FBYyxNQUFNLFFBQVEsZ0JBQWdCO0FBQzFGLG9CQUFnQixjQUFjLEdBQUcsUUFBUSxTQUFTO0FBQUEsRUFDcEQ7QUFFQSxXQUFTLGNBQWM7QUFDckIsVUFBTSxPQUFPLFFBQVEsUUFBUTtBQUM3QixVQUFNLGFBQWEsUUFBUSxZQUFZO0FBR3ZDLFFBQUksWUFBWTtBQUNkLGVBQVMsS0FBSyxVQUFVLElBQUksV0FBVztBQUN2QyxvQkFBYyxVQUFVLElBQUksUUFBUTtBQUNwQyxzQkFBZ0IsY0FBYztBQUFBLElBQ2hDLE9BQU87QUFDTCxlQUFTLEtBQUssVUFBVSxPQUFPLFdBQVc7QUFDMUMsb0JBQWMsVUFBVSxPQUFPLFFBQVE7QUFDdkMsc0JBQWdCLGNBQWM7QUFBQSxJQUNoQztBQUdBLGdCQUFZLFlBQVk7QUFHeEIsVUFBTSxVQUFVLFNBQVMsY0FBYyxJQUFJO0FBQzNDLFlBQVEsWUFBWTtBQUNwQixZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUtwQixnQkFBWSxZQUFZLE9BQU87QUFHL0IsU0FBSyxRQUFRLFFBQVEsQ0FBQyxRQUFRO0FBQzVCLFlBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxTQUFHLGFBQWEsZUFBZSxJQUFJLEVBQUU7QUFFckMsVUFBSSxZQUFZO0FBQ2QsV0FBRyxZQUFZO0FBQUE7QUFBQSwrRUFFd0QsSUFBSSxFQUFFLEtBQUssV0FBVyxJQUFJLEtBQUssQ0FBQztBQUFBO0FBQUEsZ0ZBRS9CLElBQUksRUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSWhGLE9BQU87QUFDTCxXQUFHLFlBQVk7QUFBQTtBQUFBLDJDQUVvQixXQUFXLElBQUksS0FBSyxDQUFDO0FBQUE7QUFBQTtBQUFBLE1BRzFEO0FBQ0Esa0JBQVksWUFBWSxFQUFFO0FBQUEsSUFDNUIsQ0FBQztBQUdELFFBQUksWUFBWTtBQUNkLFlBQU0sUUFBUSxTQUFTLGNBQWMsSUFBSTtBQUN6QyxZQUFNLE1BQU0sUUFBUTtBQUNwQixZQUFNLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUtsQixrQkFBWSxZQUFZLEtBQUs7QUFBQSxJQUMvQjtBQUdBLGNBQVUsWUFBWTtBQUV0QixTQUFLLEtBQUssUUFBUSxDQUFDLFFBQVE7QUFDekIsWUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLFNBQUcsYUFBYSxlQUFlLElBQUksRUFBRTtBQUdyQyxZQUFNLFVBQVUsU0FBUyxjQUFjLElBQUk7QUFDM0MsY0FBUSxZQUFZO0FBRXBCLFVBQUksWUFBWTtBQUNkLGdCQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUEsNkVBR2lELElBQUksRUFBRSxLQUFLLFdBQVcsSUFBSSxLQUFLLENBQUM7QUFBQSxrRkFDM0IsSUFBSSxFQUFFLEtBQUssV0FBVyxJQUFJLFlBQVksU0FBUyxDQUFDO0FBQUE7QUFBQTtBQUFBLGdGQUdsRCxJQUFJLEVBQUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUloRixPQUFPO0FBQ0wsZ0JBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQSx5Q0FHYSxXQUFXLElBQUksS0FBSyxDQUFDO0FBQUEsMENBQ3BCLFdBQVcsSUFBSSxZQUFZLFNBQVMsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSXpFO0FBQ0EsU0FBRyxZQUFZLE9BQU87QUFHdEIsV0FBSyxRQUFRLFFBQVEsQ0FBQyxRQUFRO0FBQzVCLGNBQU0sT0FBTyxJQUFJLE1BQU0sSUFBSSxFQUFFLEtBQUssRUFBRSxNQUFNLFVBQVUsU0FBUyxPQUFPLFlBQVksRUFBRTtBQUNsRixjQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsV0FBRyxZQUFZO0FBQ2YsV0FBRyxhQUFhLGVBQWUsSUFBSSxFQUFFO0FBQ3JDLFdBQUcsYUFBYSxlQUFlLElBQUksRUFBRTtBQUVyQyxZQUFJLEtBQUssU0FBUyxNQUFNO0FBRXRCLGFBQUcsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLakIsT0FBTztBQUVMLGdCQUFNLE1BQU0sS0FBSyxlQUFlLEtBQUssVUFBVSxNQUFNO0FBQ3JELGdCQUFNLFlBQVksUUFBUSxLQUFLLE9BQU87QUFFdEMsY0FBSSxVQUFVO0FBQ2QsY0FBSSxRQUFRLElBQUssV0FBVTtBQUFBLG1CQUNsQixNQUFNLEVBQUcsV0FBVTtBQUU1QixhQUFHLFlBQVk7QUFBQTtBQUFBO0FBQUEsK0RBR3NDLFlBQVksWUFBWSxFQUFFLGlCQUFpQixJQUFJLEVBQUUsa0JBQWtCLElBQUksRUFBRTtBQUFBO0FBQUEsMERBRTlFLE9BQU8sa0JBQWtCLElBQUksRUFBRSxrQkFBa0IsSUFBSSxFQUFFLCtCQUErQixHQUFHO0FBQUE7QUFBQTtBQUFBLFFBRzNJO0FBR0EsV0FBRyxpQkFBaUIsZUFBZSxDQUFDLE1BQU07QUFDeEMsWUFBRSxlQUFlO0FBQ2pCLDZCQUFtQjtBQUNuQixrQkFBUSxhQUFhLElBQUksSUFBSSxJQUFJLEVBQUU7QUFBQSxRQUNyQyxDQUFDO0FBRUQsV0FBRyxZQUFZLEVBQUU7QUFBQSxNQUNuQixDQUFDO0FBR0QsVUFBSSxZQUFZO0FBQ2QsY0FBTSxnQkFBZ0IsU0FBUyxjQUFjLElBQUk7QUFDakQsc0JBQWMsTUFBTSxhQUFhO0FBQ2pDLFdBQUcsWUFBWSxhQUFhO0FBQUEsTUFDOUI7QUFFQSxnQkFBVSxZQUFZLEVBQUU7QUFBQSxJQUMxQixDQUFDO0FBRUQsa0JBQWM7QUFDZCx5QkFBcUI7QUFBQSxFQUN2QjtBQUVBLFdBQVMsdUJBQXVCO0FBRTlCLGFBQVMsaUJBQWlCLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxhQUFhO0FBQ2hFLGVBQVMsaUJBQWlCLFVBQVUsQ0FBQyxNQUFNO0FBQ3pDLGNBQU0sU0FBUyxFQUFFO0FBQ2pCLGNBQU0sUUFBUSxPQUFPLGFBQWEsYUFBYTtBQUMvQyxjQUFNLFFBQVEsT0FBTyxhQUFhLGFBQWE7QUFDL0MsZ0JBQVEsa0JBQWtCLE9BQU8sT0FBTyxPQUFPLE9BQU87QUFBQSxNQUN4RCxDQUFDO0FBQUEsSUFDSCxDQUFDO0FBR0QsYUFBUyxpQkFBaUIscUJBQXFCLEVBQUUsUUFBUSxDQUFDLFVBQVU7QUFDbEUsWUFBTSxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDckMsVUFBRSxnQkFBZ0I7QUFDbEIsMkJBQW1CO0FBRW5CLGNBQU0sU0FBUyxFQUFFO0FBQ2pCLGNBQU0sUUFBUSxPQUFPLGFBQWEsYUFBYTtBQUMvQyxjQUFNLFFBQVEsT0FBTyxhQUFhLGFBQWE7QUFFL0MsY0FBTSxVQUFVLFNBQVMsY0FBYyxLQUFLO0FBQzVDLGdCQUFRLFlBQVk7QUFFcEIsY0FBTSxjQUFjLENBQUMsR0FBRyxJQUFJLElBQUksSUFBSSxHQUFHO0FBQ3ZDLG9CQUFZLFFBQVEsQ0FBQyxRQUFRO0FBQzNCLGdCQUFNLE1BQU0sU0FBUyxjQUFjLFFBQVE7QUFDM0MsY0FBSSxZQUFZO0FBQ2hCLGNBQUksY0FBYyxHQUFHLEdBQUc7QUFDeEIsY0FBSSxpQkFBaUIsU0FBUyxDQUFDLE9BQU87QUFDcEMsZUFBRyxnQkFBZ0I7QUFDbkIsb0JBQVEsa0JBQWtCLE9BQU8sT0FBTyxHQUFHO0FBQzNDLCtCQUFtQjtBQUFBLFVBQ3JCLENBQUM7QUFDRCxrQkFBUSxZQUFZLEdBQUc7QUFBQSxRQUN6QixDQUFDO0FBR0QsY0FBTSxPQUFPLE9BQU8sc0JBQXNCO0FBQzFDLGdCQUFRLE1BQU0sV0FBVztBQUN6QixnQkFBUSxNQUFNLE1BQU0sR0FBRyxLQUFLLFNBQVMsQ0FBQztBQUN0QyxnQkFBUSxNQUFNLE9BQU8sR0FBRyxLQUFLLElBQUksSUFBSSxLQUFLLE9BQU8sRUFBRSxDQUFDO0FBRXBELGlCQUFTLEtBQUssWUFBWSxPQUFPO0FBQ2pDLHdCQUFnQjtBQUFBLE1BQ2xCLENBQUM7QUFBQSxJQUNILENBQUM7QUFHRCxhQUFTLGlCQUFpQix5Q0FBeUMsRUFBRSxRQUFRLENBQUMsT0FBTztBQUNuRixTQUFHLGlCQUFpQixRQUFRLENBQUMsTUFBTTtBQUNqQyxjQUFNLFNBQVMsRUFBRTtBQUNqQixjQUFNLFFBQVEsT0FBTyxhQUFhLGFBQWE7QUFDL0MsZ0JBQVEsYUFBYSxPQUFPLE9BQU8sZUFBZSxFQUFFO0FBQUEsTUFDdEQsQ0FBQztBQUNELFNBQUcsaUJBQWlCLFdBQVcsQ0FBQyxNQUFNO0FBQ3BDLFlBQUssRUFBb0IsUUFBUSxTQUFTO0FBQ3hDLFlBQUUsZUFBZTtBQUNqQixVQUFDLEVBQUUsT0FBdUIsS0FBSztBQUFBLFFBQ2pDO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBR0QsYUFBUyxpQkFBaUIsaUJBQWlCLEVBQUUsUUFBUSxDQUFDLFFBQVE7QUFDNUQsVUFBSSxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDbkMsVUFBRSxnQkFBZ0I7QUFDbEIsY0FBTSxTQUFTLEVBQUU7QUFDakIsY0FBTSxRQUFRLE9BQU8sYUFBYSxhQUFhO0FBQy9DLFlBQUksUUFBUSw4Q0FBOEMsR0FBRztBQUMzRCxrQkFBUSxhQUFhLEtBQUs7QUFDMUIsb0JBQVUsa0JBQWtCLE1BQU07QUFBQSxRQUNwQztBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUdELGFBQVMsaUJBQWlCLHFDQUFxQyxFQUFFLFFBQVEsQ0FBQyxPQUFPO0FBQy9FLFNBQUcsaUJBQWlCLFFBQVEsQ0FBQyxNQUFNO0FBQ2pDLGNBQU0sU0FBUyxFQUFFO0FBQ2pCLGNBQU0sUUFBUSxPQUFPLGFBQWEsYUFBYTtBQUMvQyxnQkFBUSxVQUFVLE9BQU8sT0FBTyxlQUFlLEVBQUU7QUFBQSxNQUNuRCxDQUFDO0FBQ0QsU0FBRyxpQkFBaUIsV0FBVyxDQUFDLE1BQU07QUFDcEMsWUFBSyxFQUFvQixRQUFRLFNBQVM7QUFDeEMsWUFBRSxlQUFlO0FBQ2pCLFVBQUMsRUFBRSxPQUF1QixLQUFLO0FBQUEsUUFDakM7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILENBQUM7QUFHRCxhQUFTLGlCQUFpQixzQ0FBc0MsRUFBRSxRQUFRLENBQUMsT0FBTztBQUNoRixTQUFHLGlCQUFpQixRQUFRLENBQUMsTUFBTTtBQUNqQyxjQUFNLFNBQVMsRUFBRTtBQUNqQixjQUFNLFFBQVEsT0FBTyxhQUFhLGlCQUFpQjtBQUNuRCxnQkFBUSxrQkFBa0IsT0FBTyxPQUFPLGVBQWUsRUFBRTtBQUFBLE1BQzNELENBQUM7QUFDRCxTQUFHLGlCQUFpQixXQUFXLENBQUMsTUFBTTtBQUNwQyxZQUFLLEVBQW9CLFFBQVEsU0FBUztBQUN4QyxZQUFFLGVBQWU7QUFDakIsVUFBQyxFQUFFLE9BQXVCLEtBQUs7QUFBQSxRQUNqQztBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUdELGFBQVMsaUJBQWlCLGlCQUFpQixFQUFFLFFBQVEsQ0FBQyxRQUFRO0FBQzVELFVBQUksaUJBQWlCLFNBQVMsQ0FBQyxNQUFNO0FBQ25DLFVBQUUsZ0JBQWdCO0FBQ2xCLGNBQU0sU0FBUyxFQUFFO0FBQ2pCLGNBQU0sUUFBUSxPQUFPLGFBQWEsYUFBYTtBQUMvQyxZQUFJLFFBQVEsMkNBQTJDLEdBQUc7QUFDeEQsa0JBQVEsVUFBVSxLQUFLO0FBQ3ZCLG9CQUFVLGVBQWUsTUFBTTtBQUFBLFFBQ2pDO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBR0QsVUFBTSxrQkFBa0IsU0FBUyxlQUFlLG9CQUFvQjtBQUNwRSxRQUFJLGlCQUFpQjtBQUNuQixzQkFBZ0IsaUJBQWlCLFNBQVMsTUFBTTtBQUM5QyxnQkFBUSxVQUFVO0FBQ2xCLGtCQUFVLG9CQUFvQixTQUFTO0FBQUEsTUFDekMsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsV0FBUyxXQUFXLEtBQXFCO0FBQ3ZDLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLGNBQWM7QUFDbEIsV0FBTyxJQUFJO0FBQUEsRUFDYjtBQUdBLGdCQUFjLGlCQUFpQixTQUFTLE1BQU07QUFDNUMsVUFBTSxTQUFTLFFBQVEsZUFBZTtBQUN0QyxjQUFVLFNBQVMsNkJBQTZCLGdDQUFnQyxNQUFNO0FBQUEsRUFDeEYsQ0FBQztBQUVELFlBQVUsaUJBQWlCLFNBQVMsTUFBTTtBQUN4QyxZQUFRLFVBQVU7QUFDbEIsY0FBVSxvQkFBb0IsU0FBUztBQUFBLEVBQ3pDLENBQUM7QUFFRCxZQUFVLGlCQUFpQixTQUFTLE1BQU07QUFDeEMsWUFBUSxPQUFPO0FBQ2YsY0FBVSx1QkFBdUIsU0FBUztBQUFBLEVBQzVDLENBQUM7QUFFRCxrQkFBZ0IsaUJBQWlCLFNBQVMsTUFBTTtBQUM5QyxZQUFRLE9BQU87QUFDZixjQUFVLHVCQUF1QixTQUFTO0FBQUEsRUFDNUMsQ0FBQztBQUVELFlBQVUsaUJBQWlCLFNBQVMsWUFBWTtBQUM5QyxVQUFNLFVBQVUsTUFBTSxRQUFRLFlBQVk7QUFDMUMsUUFBSSxTQUFTO0FBQ1gsZ0JBQVUsa0NBQWtDLFNBQVM7QUFBQSxJQUN2RCxPQUFPO0FBQ0wsZ0JBQVUsbUNBQW1DLE1BQU07QUFBQSxJQUNyRDtBQUFBLEVBQ0YsQ0FBQztBQUVELGdCQUFjLGlCQUFpQixTQUFTLE1BQU07QUFDNUMsVUFBTSxVQUFVLGtDQUFrQyxtQkFBbUIsS0FBSyxVQUFVLFFBQVEsUUFBUSxHQUFHLE1BQU0sQ0FBQyxDQUFDO0FBQy9HLFVBQU0saUJBQWlCLFNBQVMsY0FBYyxHQUFHO0FBQ2pELG1CQUFlLGFBQWEsUUFBUSxPQUFPO0FBQzNDLG1CQUFlLGFBQWEsWUFBWSxtQkFBbUI7QUFDM0QsYUFBUyxLQUFLLFlBQVksY0FBYztBQUN4QyxtQkFBZSxNQUFNO0FBQ3JCLG1CQUFlLE9BQU87QUFDdEIsY0FBVSw4QkFBOEIsU0FBUztBQUFBLEVBQ25ELENBQUM7QUFFRCxrQkFBZ0IsaUJBQWlCLFVBQVUsQ0FBQyxNQUFNO0FBQ2hELFVBQU0sU0FBUyxFQUFFO0FBQ2pCLFFBQUksT0FBTyxTQUFTLE9BQU8sTUFBTSxDQUFDLEdBQUc7QUFDbkMsWUFBTSxTQUFTLElBQUksV0FBVztBQUM5QixhQUFPLFNBQVMsQ0FBQyxVQUFVO0FBQ3pCLGNBQU0sVUFBVSxNQUFNLFFBQVE7QUFDOUIsWUFBSSxRQUFRLGFBQWEsT0FBTyxHQUFHO0FBQ2pDLG9CQUFVLGlDQUFpQyxTQUFTO0FBQUEsUUFDdEQsT0FBTztBQUNMLG9CQUFVLCtCQUErQixNQUFNO0FBQUEsUUFDakQ7QUFBQSxNQUNGO0FBQ0EsYUFBTyxXQUFXLE9BQU8sTUFBTSxDQUFDLENBQUM7QUFBQSxJQUNuQztBQUFBLEVBQ0YsQ0FBQztBQUVELGVBQWEsaUJBQWlCLFNBQVMsTUFBTTtBQUMzQyxRQUFJLFFBQVEsc0NBQXNDLEdBQUc7QUFDbkQsY0FBUSxlQUFlO0FBQ3ZCLGdCQUFVLGtDQUFrQyxNQUFNO0FBQUEsSUFDcEQ7QUFBQSxFQUNGLENBQUM7QUFHRCxVQUFRLFVBQVUsTUFBTTtBQUN0QixnQkFBWTtBQUFBLEVBQ2QsQ0FBQztBQUdELFFBQU0sUUFBUSxnQkFBZ0I7QUFDOUIsY0FBWTtBQUNkLENBQUM7IiwibmFtZXMiOltdfQ==